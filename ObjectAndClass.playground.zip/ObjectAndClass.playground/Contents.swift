import Cocoa

var MacBookColors = ["Green", "Blue", "White"]
var MacBookNames = ["Frisk", "Chara", "Sans"]
var MacBookBrands = ["Undertale", "ABC", "Loi"]

var MacBookPrice = [5000, 100000, 10]
var index = 0

for index in 0...2{
print("\(MacBookColors [index]) \(MacBookNames [index]) \(MacBookBrands [index])")
}

class MacBook {
    
    var color = "Green"
    var name = "FriskChara"
    var brand = "LOVE"
    
    func run() {
        print("Macbook is running")
    }
}

let Macbook = MacBook()
Macbook.color = "AAA"
//Macbook.run()
//print("Runnn Macbook: \(Macbook.color)")

let MacBook01 = MacBook()
MacBook01.color = "greennnnnnnnnnn"
MacBook01.run()

print("MacBook01 color: \(MacBook01.color)")
