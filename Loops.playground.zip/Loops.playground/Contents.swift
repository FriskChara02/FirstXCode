import Cocoa

var student01Score = 10.0
var student02Score = 9.0
var student03Score = 8.0
var student04Score = 9.5
var student05Score = 9.75

var sumOfScore = student01Score + student02Score + student03Score + student04Score + student05Score

var averageScore = sumOfScore / 5

var studentScores = [10.0, 9, 8, 9.5, 9.75, 7]

var sumScore = studentScores[0] + studentScores[1] + studentScores[2] + studentScores[3] + studentScores[4] + studentScores[5]
var averScore = sumScore / Double(studentScores.count)

var index = 0

var sumScore02 = 0.0
repeat {
    sumScore02 += studentScores[index]
    index += 1
} while(index < studentScores.count)
        var aveScore = sumScore02 / Double(studentScores.count)
        
        for i in 0..<studentScores.count {
    print("i = \(i)")
}

for x in 1..<10{ //i...10 có nghĩa là i chạy từ 1 đến 10 - i..< có nghĩa là chạy từ 1 bé hơn 10
    print("x = \(x)")
}
