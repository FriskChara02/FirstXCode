import Cocoa

class Enemy {
    var hp = 10
    
    func attack() {

    }
}

class Solder: Enemy {

    override func attack() {
        print("Open Fỉre")
    }
}

class Tank: Enemy {

    override func attack() {
        print("Panther V is coming")
    }
}

var Enemies: [Enemy] = [Tank(), Solder(), Tank(), Tank(), Solder()]
for Enemy in Enemies {
    Enemy.attack()
}
