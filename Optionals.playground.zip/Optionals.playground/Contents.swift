import Cocoa

var yourName: String = "Someone"
var myName: String? = "FriskChara"

if myName != nil {
        print("My name is \(myName!)")
    }else{
        print("My name is nil")
}

if let constantMyName = myName {
        var combine = constantMyName + yourName
    }else{
        print("My name is nil")
}

@MainActor func printOptional() {
    guard let name = myName else {return}
    print("Name is \(name)")
}

printOptional()







class Car {
    var engine: Engine?
    init(engine: Engine?) {
        self.engine = engine
    }
}

class Engine {
    var type: String = "V6"
}

var carOptional: Car? = Car(engine: Engine())

if let eng = carOptional?.engine {
    print("Engine type is \(eng.type)")
}
