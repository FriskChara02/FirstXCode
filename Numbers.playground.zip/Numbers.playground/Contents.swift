import UIKit

//Type inference
var age = 15 //int

var number: Double = 123456789123456789123456789123456789

var number2 = 75.5

var number3: Float = 5.2


var n = 5 * 5
var t = 3 + 4
var h = 15 - 3
var c = 10 / 2

var c2 = 13 / 5
var c3 = 13 % 5

var randomNumber = 5

if randomNumber % 2 == 0 {
    var result = "Day la so chan"
}else{
    var result = "Day la so le"
}

var c4 = -13.4 / 2

var bt = (10+2) / 5  * (4 - 7)
