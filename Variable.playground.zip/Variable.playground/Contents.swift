import UIKit

//Variable (Bien)
var greeting = "Hello, playground" //greeting, number, ... la ten bien - "=" la toan tu.

var number = 5

var numberOfMember: Int = 6

var isGreen: Bool = false //Bool la kieu du lieu dung hay sai.

//Operators (Toan tu)

var isNotGreen = !isGreen

var result = isNotGreen ? "Khong phai mau xanh" : "La mau xanh"

var isNumberBigger = number == 5
