import Cocoa

var studentName01 = "Jake"
var studentName02 = "Hiu"
var studentName03 = "Dun"
var studentName04 = "FriskChara"

var studentName: [String] = ["Jake", "Hiu", "Dun", "FriskChar"]

print(studentName.count)
studentName.append("Halo")
print(studentName.count)

studentName.remove(at: 1)

print(studentName.count)

var carNames = [String]()
print(carNames.count)
