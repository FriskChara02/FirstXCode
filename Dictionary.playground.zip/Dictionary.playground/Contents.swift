import Cocoa

var numberToStrings = [Int: String]() // key bên trái, value bên phải

numberToStrings [1] = "One"

var students: [String: String] = ["SV1": "FriskChara", "SV2": "Jake", "SV3": "Hiu"]

print("Size of students: \(students.count)")

students["SV4"] = "ABC"

students["SV4"] = "NEW ABC"

students["SV5"] = "DUN"

students["SV5"] = nil

for (masv, name) in students { // key bên trái, value bên phải
    print("\(masv): \(name)")
}

for key in students.keys {
    print("\(key)")
}

for value in students.values {
    print("\(value)")
}
