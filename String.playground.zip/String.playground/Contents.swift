import UIKit

var greeting = "Khong tuong minh"
var greetings: String = "Tuong minh"

var HoTen = "Loi Nguyen"
var Year = "20 tuoi"
var Time = 99
var You = HoTen + " " + Year
//or (cach noi xuyen)
var You2 = "\(HoTen) \(Year) \(Time)"
You2.append(contentsOf: " 999")

var MyName = "nguyen bao loi"
MyName = MyName.capitalized

var CapsAll = "HAHAHAHA"
CapsAll = CapsAll.lowercased()

var message = "Choi game non qua"
message.replacingOccurrences(of: "non", with: "hay")

if message.contains("non"){
    message = "***"
}
