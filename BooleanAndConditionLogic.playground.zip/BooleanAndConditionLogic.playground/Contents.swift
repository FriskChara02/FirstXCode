import Cocoa

var isGreen: Bool = false
isGreen = true

var hp = 999

if hp == 0 {
    print("You're dead")
}

var mana = 1000
var manaOfSkill = 1000

var canUseSkill = manaOfSkill <= mana && hp > 0

if canUseSkill{
    print("Your skill is ready")
}else{
    print("Wait!!!!!")
}

var skill01 = "Frisk"
var skill02 = "Chara"

if skill01 == skill02{
    print("They're the same name")
}else{
    print("They're not the same name")
}
