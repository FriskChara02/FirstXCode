import Cocoa

class Solder {
    var hp = 100
    var armor = 100
    var damage = 50

    init() {
        print("I'm your enemy")
    }

    func attack() {
        print("Open Fire")
    }

    func die() {
        print("My Sol is dyinggg")
    }
}

class Tank: Solder{
    override init() {
        super.init()

        print("Panther V")
        hp = 1000
        armor = 1000
        damage = 100
}

    override func attack() {
        print("OPEN FIRE - Got Hit")
    }
}

class Medic: Solder {
    override init() {
        super.init()
        print("I'm coming help ya")
        
        hp = 100
        armor = 0
        damage = 10

}

    override func attack() {
        print("Let's me heal")
    }
}

    let solder = Tank()
    solder.attack()

    let solder02 = Medic()
    solder02.attack()

    let solder03 = Solder()
    solder03.die()
