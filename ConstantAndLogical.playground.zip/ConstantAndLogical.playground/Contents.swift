import Cocoa

let isBuilDebug = true

if isBuilDebug != true {
    print("Build is not debug build")
}

let haveTicket = true
let isAdult = false
let isVip = true

if haveTicket && isAdult || isVip { // || là toán tử hoặc
    print("Can get on a helicopter")
}else{
    print("You can't get in the helicopter")
}
